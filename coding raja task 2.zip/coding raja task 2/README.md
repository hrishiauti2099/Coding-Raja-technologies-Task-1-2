# Coding-Raja-Technologies-Internship
Internship task 2 i.e Music Player
